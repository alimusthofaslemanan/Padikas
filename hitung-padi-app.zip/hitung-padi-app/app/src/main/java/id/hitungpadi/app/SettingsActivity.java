package id.hitungpadi.app;

import android.Manifest;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Layar pengaturan widget: tanggal tanam, umur panen, lokasi cuaca. */
public class SettingsActivity extends Activity {

    private Button btnTanggal;
    private EditText etUmur, etLat, etLon;
    private LocalDate tanam;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_settings);

        btnTanggal = findViewById(R.id.btnTanggal);
        etUmur = findViewById(R.id.etUmur);
        etLat = findViewById(R.id.etLat);
        etLon = findViewById(R.id.etLon);

        SharedPreferences p = Core.prefs(this);
        tanam = Core.tanam(this);
        etUmur.setText(String.valueOf(Core.umur(this)));
        etLat.setText(p.getString("lat", ""));
        etLon.setText(p.getString("lon", ""));
        tampilTanggal();

        btnTanggal.setOnClickListener(v -> pilihTanggal());
        findViewById(R.id.btnLok).setOnClickListener(v -> ambilLokasi());
        findViewById(R.id.btnSimpan).setOnClickListener(v -> simpan());
    }

    private void tampilTanggal() {
        btnTanggal.setText(tanam == null ? "Pilih tanggal"
                : tanam.format(DateTimeFormatter.ofPattern("d MMMM yyyy", new Locale("id", "ID"))));
    }

    private void pilihTanggal() {
        LocalDate d = tanam != null ? tanam : LocalDate.now();
        new DatePickerDialog(this, (view, y, m, day) -> {
            tanam = LocalDate.of(y, m + 1, day);
            tampilTanggal();
        }, d.getYear(), d.getMonthValue() - 1, d.getDayOfMonth()).show();
    }

    private void ambilLokasi() {
        if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
            return;
        }
        LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        Location best = null;
        for (String prov : lm.getProviders(true)) {
            Location l = lm.getLastKnownLocation(prov);
            if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
        }
        if (best == null) {
            Toast.makeText(this, "Lokasi belum tersedia. Nyalakan GPS, buka Google Maps sebentar, "
                    + "lalu coba lagi atau isi manual.", Toast.LENGTH_LONG).show();
            return;
        }
        etLat.setText(String.format(Locale.US, "%.4f", best.getLatitude()));
        etLon.setText(String.format(Locale.US, "%.4f", best.getLongitude()));
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) ambilLokasi();
    }

    private void simpan() {
        SharedPreferences.Editor e = Core.prefs(this).edit();
        if (tanam != null) e.putString("tanam", tanam.toString());

        int umur = Core.UMUR_DEFAULT;
        try { umur = Integer.parseInt(etUmur.getText().toString().trim()); } catch (Exception ignored) { }
        e.putInt("umur", Math.max(30, Math.min(200, umur)));

        String lat = etLat.getText().toString().trim();
        String lon = etLon.getText().toString().trim();
        try {
            Double.parseDouble(lat);
            Double.parseDouble(lon);
            e.putString("lat", lat).putString("lon", lon).remove("cuaca_ada");
        } catch (Exception ex) {
            e.remove("lat").remove("lon").remove("cuaca_ada");
        }
        e.apply();

        Core.refreshWidgets(this);
        Toast.makeText(this, "Tersimpan. Widget diperbarui.", Toast.LENGTH_SHORT).show();
        finish();
    }
}
