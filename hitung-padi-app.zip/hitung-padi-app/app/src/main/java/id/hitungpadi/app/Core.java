package id.hitungpadi.app;

import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.time.LocalDate;

/** Data fase tanam, penyimpanan pengaturan, dan helper bersama. */
public class Core {

    /** Alamat PWA. Ganti di sini jika domain berubah. */
    public static final String APP_URL = "https://hitungkeuntunganpadi.lovable.app";

    static final String PREFS = "padi";
    static final int UMUR_DEFAULT = 110;

    static class Phase {
        final String emoji, name;
        final int from, to; // HST (hari setelah tanam), inklusif
        Phase(String emoji, String name, int from, int to) {
            this.emoji = emoji; this.name = name; this.from = from; this.to = to;
        }
    }

    /**
     * Jadwal fase (HST). Silakan sesuaikan angka di sini dengan jadwal Anda.
     * Fase "Masak Susu-Kuning" berakhir sehari sebelum umur panen (dihitung otomatis).
     */
    static Phase[] phases(int umur) {
        return new Phase[] {
            new Phase("🌱", "Persemaian Benih",         -21, -4),
            new Phase("🚜", "Olah Lahan & Tanam",        -3,  0),
            new Phase("🧪", "Pemupukan Dasar",            1,  7),
            new Phase("🌿", "Penyiangan I",              14, 20),
            new Phase("🧪", "Pemupukan Susulan II",      21, 28),
            new Phase("🌿", "Penyiangan II",             35, 42),
            new Phase("🌾", "Primordia / Pemupukan III", 43, 55),
            new Phase("🌸", "Pembungaan",                56, 70),
            new Phase("🌾", "Pengisian Bulir",           71, 85),
            new Phase("🟡", "Masak Susu-Kuning",         86, umur - 1),
            new Phase("🧺", "Panen",                   umur, umur + 7),
        };
    }

    static Phase current(int hst, int umur) {
        for (Phase p : phases(umur)) if (hst >= p.from && hst <= p.to) return p;
        return null;
    }

    static Phase next(int hst, int umur) {
        for (Phase p : phases(umur)) if (p.from > hst) return p;
        return null;
    }

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static LocalDate tanam(Context c) {
        String s = prefs(c).getString("tanam", "");
        if (s.isEmpty()) return null;
        try { return LocalDate.parse(s); } catch (Exception e) { return null; }
    }

    static int umur(Context c) {
        return prefs(c).getInt("umur", UMUR_DEFAULT);
    }

    static void refreshWidgets(Context c) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(c);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(c, PadiWidget.class));
        Intent i = new Intent(c, PadiWidget.class);
        i.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
        c.sendBroadcast(i);
    }

    /** Kode cuaca WMO (Open-Meteo) -> [emoji, teks Indonesia]. */
    static String[] cuaca(int code) {
        if (code == 0) return new String[]{"☀️", "Cerah"};
        if (code == 1 || code == 2) return new String[]{"🌤️", "Cerah berawan"};
        if (code == 3) return new String[]{"☁️", "Berawan"};
        if (code == 45 || code == 48) return new String[]{"🌫️", "Berkabut"};
        if (code >= 51 && code <= 57) return new String[]{"🌦️", "Gerimis"};
        if (code == 61) return new String[]{"🌧️", "Hujan ringan"};
        if (code == 63) return new String[]{"🌧️", "Hujan sedang"};
        if (code == 65 || code == 67) return new String[]{"🌧️", "Hujan lebat"};
        if (code >= 71 && code <= 77) return new String[]{"❄️", "Salju"};
        if (code >= 80 && code <= 82) return new String[]{"🌧️", "Hujan deras sesaat"};
        if (code >= 95) return new String[]{"⛈️", "Badai petir"};
        return new String[]{"🌡️", "Cuaca"};
    }
}
