package id.hitungpadi.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

public class PadiWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(final Context ctx, final AppWidgetManager mgr, final int[] ids) {
        render(ctx, mgr, ids);

        // Ambil cuaca terbaru di thread terpisah, lalu gambar ulang.
        SharedPreferences p = Core.prefs(ctx);
        if (!p.contains("lat") || !p.contains("lon")) return;
        final BroadcastReceiver.PendingResult pr = goAsync();
        new Thread(() -> {
            try {
                fetchWeather(ctx, Double.parseDouble(p.getString("lat", "0")),
                        Double.parseDouble(p.getString("lon", "0")));
                render(ctx, mgr, ids);
            } catch (Exception ignored) {
            } finally {
                pr.finish();
            }
        }).start();
    }

    static void fetchWeather(Context ctx, double lat, double lon) throws Exception {
        String url = String.format(Locale.US,
                "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
                        + "&current=temperature_2m,weather_code&daily=precipitation_probability_max"
                        + "&forecast_days=1&timezone=auto", lat, lon);
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            JSONObject j = new JSONObject(sb.toString());
            JSONObject cur = j.getJSONObject("current");
            int hujan = j.getJSONObject("daily").getJSONArray("precipitation_probability_max").optInt(0, 0);
            Core.prefs(ctx).edit()
                    .putInt("cuaca_kode", cur.getInt("weather_code"))
                    .putInt("cuaca_t", (int) Math.round(cur.getDouble("temperature_2m")))
                    .putInt("cuaca_hujan", hujan)
                    .putBoolean("cuaca_ada", true)
                    .apply();
        } finally {
            c.disconnect();
        }
    }

    static void render(Context ctx, AppWidgetManager mgr, int[] ids) {
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("d MMM yyyy", new Locale("id", "ID"));
        RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_padi);
        SharedPreferences p = Core.prefs(ctx);
        LocalDate tanam = Core.tanam(ctx);
        int umur = Core.umur(ctx);

        if (tanam == null) {
            v.setTextViewText(R.id.hstText, "HST -");
            v.setTextViewText(R.id.sekarangIcon, "🌱");
            v.setTextViewText(R.id.sekarangText, "Ketuk untuk mengatur");
            v.setTextViewText(R.id.berikutText, "Berikutnya: -");
            v.setTextViewText(R.id.panenText, "Est. panen: -");
            v.setProgressBar(R.id.progress, 100, 0, false);
        } else {
            LocalDate today = LocalDate.now();
            int hst = (int) ChronoUnit.DAYS.between(tanam, today);
            Core.Phase now = Core.current(hst, umur);
            Core.Phase nxt = Core.next(hst, umur);

            v.setTextViewText(R.id.hstText, "HST " + hst);
            if (hst > umur + 7) {
                v.setTextViewText(R.id.sekarangIcon, "✅");
                v.setTextViewText(R.id.sekarangText, "Musim tanam selesai");
            } else if (now != null) {
                v.setTextViewText(R.id.sekarangIcon, now.emoji);
                v.setTextViewText(R.id.sekarangText, now.name);
            } else {
                v.setTextViewText(R.id.sekarangIcon, "💧");
                v.setTextViewText(R.id.sekarangText, "Perawatan rutin (jaga air & hama)");
            }

            if (nxt != null) {
                v.setTextViewText(R.id.berikutIcon, nxt.emoji);
                v.setTextViewText(R.id.berikutText,
                        "Berikutnya: " + nxt.name + " (" + (nxt.from - hst) + " hari lagi)");
            } else {
                v.setTextViewText(R.id.berikutIcon, "➡️");
                v.setTextViewText(R.id.berikutText, "Berikutnya: -");
            }

            int pct = Math.max(0, Math.min(100, hst * 100 / Math.max(1, umur)));
            v.setProgressBar(R.id.progress, 100, pct, false);

            LocalDate panen = tanam.plusDays(umur);
            long sisa = ChronoUnit.DAYS.between(today, panen);
            String ket = sisa < 0 ? " (sudah lewat)" : sisa == 0 ? " (hari ini)" : " (" + sisa + " hari lagi)";
            v.setTextViewText(R.id.panenText, "Est. panen " + fmt.format(panen) + ket);
        }

        // Cuaca
        if (!p.contains("lat") || !p.contains("lon")) {
            v.setTextViewText(R.id.cuacaIcon, "📍");
            v.setTextViewText(R.id.cuacaText, "Cuaca: atur lokasi di app");
        } else if (!p.getBoolean("cuaca_ada", false)) {
            v.setTextViewText(R.id.cuacaIcon, "⏳");
            v.setTextViewText(R.id.cuacaText, "Cuaca: menunggu internet");
        } else {
            String[] c = Core.cuaca(p.getInt("cuaca_kode", 0));
            v.setTextViewText(R.id.cuacaIcon, c[0]);
            v.setTextViewText(R.id.cuacaText, c[1] + " " + p.getInt("cuaca_t", 0) + "°C · hujan "
                    + p.getInt("cuaca_hujan", 0) + "%");
        }

        // Ketuk badan widget -> buka aplikasi (PWA); ketuk header -> pengaturan.
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        v.setOnClickPendingIntent(R.id.root,
                PendingIntent.getActivity(ctx, 0, new Intent(ctx, MainActivity.class), flags));
        v.setOnClickPendingIntent(R.id.header,
                PendingIntent.getActivity(ctx, 1, new Intent(ctx, SettingsActivity.class), flags));

        mgr.updateAppWidget(ids, v);
    }
}
