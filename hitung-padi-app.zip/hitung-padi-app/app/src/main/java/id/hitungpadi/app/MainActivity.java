package id.hitungpadi.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.time.LocalDate;

/** Membungkus PWA di WebView + tombol kecil untuk pengaturan widget. */
public class MainActivity extends Activity {

    private WebView web;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        FrameLayout root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        float d = getResources().getDisplayMetrics().density;
        TextView fab = new TextView(this);
        fab.setText("🌾 Widget");
        fab.setTextColor(Color.WHITE);
        fab.setTextSize(13);
        fab.setPadding((int) (14 * d), (int) (9 * d), (int) (14 * d), (int) (9 * d));
        fab.setBackgroundColor(Color.parseColor("#CC2E7D32"));
        fab.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.END);
        lp.setMargins(0, 0, (int) (12 * d), (int) (16 * d));
        root.addView(fab, lp);
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);      // localStorage untuk PWA
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (u.getHost() != null && u.getHost().equals(Uri.parse(Core.APP_URL).getHost())) {
                    return false; // tetap di dalam app
                }
                startActivity(new Intent(Intent.ACTION_VIEW, u)); // link luar -> browser
                return true;
            }
        });

        // Jembatan opsional: PWA bisa memanggil window.AndroidWidget.* dari JavaScript.
        web.addJavascriptInterface(new Bridge(), "AndroidWidget");

        web.loadUrl(Core.APP_URL);
    }

    class Bridge {
        /** AndroidWidget.openSettings() */
        @JavascriptInterface
        public void openSettings() {
            runOnUiThread(() -> startActivity(new Intent(MainActivity.this, SettingsActivity.class)));
        }

        /** AndroidWidget.setTanam("2026-11-02") -> isi widget langsung dari PWA. */
        @JavascriptInterface
        public void setTanam(String iso) {
            try {
                LocalDate.parse(iso);
                Core.prefs(MainActivity.this).edit().putString("tanam", iso).apply();
                Core.refreshWidgets(MainActivity.this);
            } catch (Exception ignored) { }
        }

        /** AndroidWidget.setUmur(110) */
        @JavascriptInterface
        public void setUmur(int hari) {
            if (hari < 30 || hari > 200) return;
            Core.prefs(MainActivity.this).edit().putInt("umur", hari).apply();
            Core.refreshWidgets(MainActivity.this);
        }
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        Core.refreshWidgets(this);
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }
}
