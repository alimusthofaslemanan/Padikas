# Hitung Padi (APK + Widget)

Membungkus PWA https://hitungkeuntunganpadi.lovable.app menjadi APK, dengan widget layar utama
(fase tanam, HST, fase berikutnya, cuaca, estimasi panen).

## Cara build lewat GitHub
1. Buat repo baru di GitHub, upload seluruh isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions** -> workflow **Build APK** berjalan otomatis (atau klik *Run workflow*).
3. Setelah hijau, buka run tersebut -> **Artifacts** -> unduh `HitungPadi-APK` (isinya `HitungPadi.apk`).

## Memakai widget
1. Pasang APK, buka app, tekan tombol **🌾 Widget** -> isi tanggal tanam, umur panen, lokasi -> SIMPAN.
2. Tekan lama layar utama -> Widget -> **Hitung Padi**.
3. Ketuk header widget = pengaturan, ketuk badan widget = buka app.

## Kustomisasi
- URL PWA: `Core.APP_URL` di `app/src/main/java/id/hitungpadi/app/Core.java`
- Jadwal fase: `Core.phases()` di file yang sama.
- Dari PWA bisa memanggil: `window.AndroidWidget?.setTanam("2026-11-02")`, `setUmur(110)`, `openSettings()`.
